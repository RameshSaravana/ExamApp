import React, { useState } from 'react';

function App() {
  const [apiUrl, setExchange] = useState('');
  const [paramToken, setToken] = useState('');
  const [paramResolution, setResolution] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [responseData, setResponseData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Predefined API options
  const apiOptions = [
    { label: 'Select Exchange', value: '' },
    { label: 'NFO', value: 'NFO' },
    { label: 'NSE', value: 'NSE' },
    { label: 'Equity', value: 'EQ' }
  ];

   // Predefined API options
   const apiResolution = [
    { label: 'Select Resolution', value: '' },
    { label: '5-Minutes', value: '5' },
    { label: '10-Minutes', value: '10' },
    { label: '15-Minutes', value: '15' },
    { label: '30-Minutes', value: '30' },
    { label: '1-Day', value: '1D' }
  ];

  const handleFetch = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setResponseData(null);

    // Construct query parameters
    let queryParams = [];
    const requestData = { 
      token: paramToken? encodeURIComponent(paramToken) : 'NFO',
      resolution: paramResolution? encodeURIComponent(paramResolution) : 'NFO',
      from: fromDate? encodeURIComponent(fromDate) : 'NFO',
      to: toDate? encodeURIComponent(toDate) : 'NFO',
      exchange: paramResolution? encodeURIComponent(paramResolution) : 'NFO'
    };          
    

    if (setResolution) {
      //queryParams.push(`${encodeURIComponent(paramKey)}=${encodeURIComponent(paramValue)}`);
      queryParams.push(`resolution=${encodeURIComponent(paramResolution)}`);
      
    } 
    if (fromDate) {
      queryParams.push(`fromDate=${encodeURIComponent(fromDate)}`);
    }
    if (toDate) {
      queryParams.push(`toDate=${encodeURIComponent(toDate)}`);
    }

    // Append query parameters to API URL
    let fullUrl = apiUrl;
    if (queryParams.length > 0) {
      fullUrl += `?${queryParams.join('&')}`;
    }

    try {
      console.log("testing");
      console.log(fullUrl);
      const response = await fetch(fullUrl);
      if (!response.ok) {
        throw new Error(`HTTP Error: ${response.status}`);
      }
      const data = await response.json();
      setResponseData(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial' }}>
      <h2>Market Marking</h2>
      <form onSubmit={handleFetch}>
        {/* Dropdown for API selection */}
        <label>Exchange: </label>
        <select
          onChange={(e) => setExchange(e.target.value)}
          value={apiUrl}
          style={{ width: '320px', padding: '8px', marginBottom: '10px' }}
        >
          {apiOptions.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        
        <br />
        {/* Dropdown for API Resolution */}
        <label>Resolution: </label>
        <select
          onChange={(e) => setResolution(e.target.value)}
          value={apiUrl}
          style={{ width: '320px', padding: '8px', marginBottom: '10px' }}
        >
          {apiResolution.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        
        <br />

        {/* Input for optional query parameters */}
        <label>Token: </label>
        <input
          type="text"
          placeholder="ENter Token Number#"
          value={paramToken}
          onChange={(e) => setToken(e.target.value)}
          style={{ width: '140px', padding: '8px', marginRight: '10px' }}
        />
        {/* <input
          type="text"
          placeholder="Parameter Value (optional)"
          value={paramValue}
          onChange={(e) => setParamValue(e.target.value)}
          style={{ width: '140px', padding: '8px', marginRight: '10px' }}
        />
       */}
         <br /> 
        {/* From Date and To Date Fields */}
        <label>From Date: </label>
        <input
          type="date"
          value={fromDate}
          onChange={(e) => setFromDate(e.target.value)}
          style={{ padding: '8px', marginRight: '10px' }}
        />
        <br />
        {/* From Date and To Date Fields */}
        <label>To Date: </label>
        <input
          type="date"
          value={toDate}
          onChange={(e) => setToDate(e.target.value)}
          style={{ padding: '8px' }}
        />
        <br />

        <button type="submit" style={{ padding: '8px', marginTop: '10px' }} disabled={!apiUrl}>
          Fetch
        </button>
      </form>

      {loading && <p>Loading...</p>}
      {error && <p style={{ color: 'red' }}>Error: {error}</p>}

      {responseData && (
        <div style={{ marginTop: '20px', whiteSpace: 'pre-wrap', background: '#f4f4f4', padding: '10px' }}>
          <h3>Response:</h3>
          <pre>{JSON.stringify(responseData, null, 2)}</pre>
        </div>
      )}
    </div>
  );
}

export default App;
